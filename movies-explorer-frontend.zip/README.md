# movies-explorer-frontend
Front_for_Diploma

URL: ***

Figma: https://disk.yandex.ru/d/hLBmVEz7bor7Xg

Link: https://huxt-huxt.nomoredomains.club

Pull request: https://github.com/HuXT-HuXT/movies-explorer-frontend/pull/2

